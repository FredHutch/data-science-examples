function timeToComplete = my_parallel_app(pauseLength)
%% Computation

numWorkers = getenv('SLURM_NTASKS');
fprintf('\nUsing %s cores for this computation.\n\n', numWorkers)

% In case the user did not specify a pause length
if nargin < 1 || pauseLength < 0
    pauseLength = 2;
end

% PARFOR
t0 = tic;
parfor idx = 1:(str2num(numWorkers)*8)
    pause(pauseLength)
end
timeToComplete = toc(t0);

fprintf('parfor completed in %.2f seconds.\n\n', timeToComplete)

% SPMD
spmd
   o = gop(@plus,labindex);
end

fprintf('Cumilitive sum of all worker indices is %i.\n\n', o{end})

%% Save  Reults

% Determine the user's home directory - replace with your $HOME
uh = java.lang.System.getProperty('user.home');
homeDir = char(uh);
cd(homeDir)

fileName = 'batch-results.mat';
save(fileName, 't0')

fprintf('Saved runtime results to %s.\n\n', fullfile(homeDir,fileName))

fprintf('Batch script successfully completed. Exiting.\n')

end