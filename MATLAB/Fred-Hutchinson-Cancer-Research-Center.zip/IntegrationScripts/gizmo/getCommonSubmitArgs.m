function commonSubmitArgs = getCommonSubmitArgs(cluster, numWorkers)
% Get any additional submit arguments for the Slurm sbatch command
% that are common to both independent and communicating jobs.

% Copyright 2016-2019 The MathWorks, Inc.

% wiki: 

commonSubmitArgs = '';

% Number of cores/node
ppn = validatedPropValue(cluster, 'ProcsPerNode', 'double');
if ppn>0
    % Don't request more cores/node than workers
    ppn = min(numWorkers,ppn);
    commonSubmitArgs = sprintf('%s --ntasks-per-node=%d',commonSubmitArgs,ppn);
end
commonSubmitArgs = sprintf('%s --ntasks-per-core=1',commonSubmitArgs);


%% REQUIRED

% % Partition / Check for GPU
% ngpus = validatedPropValue(cluster, 'GpusPerNode', 'double');
% if ngpus>0
%     qn = 'gpu';
% else
%     qn = validatedPropValue(cluster, 'QueueName', 'char');
% end
% if isempty(qn)
%     emsg = sprintf(['\n\t>> %% Must set QueueName to use.  E.g.\n\n', ...
%                     '\t>> c = parcluster;\n', ...
%                     '\t>> c.AdditionalProperties.QueueName = ''queue-name'';\n', ...
%                     '\t>> c.saveProfile\n\n']);
%     error(emsg) %#ok<SPERR>
% else
%     commonSubmitArgs = [commonSubmitArgs ' -p ' qn];
% end


%% OPTIONAL

% AccountName
an = validatedPropValue(cluster, 'AccountName', 'char');
if ~isempty(an)
    commonSubmitArgs = [commonSubmitArgs ' -A ' an];
end

% Check for GPU
% ngpus = validatedPropValue(cluster, 'GpusPerNode', 'double');
% if ~isempty(ngpus) && ngpus > 0 
%    commonSubmitArgs = [commonSubmitArgs ' --gres=gpu'];
% end

% Partition
qn = validatedPropValue(cluster, 'QueueName', 'char');
if ~isempty(qn)
    commonSubmitArgs = [commonSubmitArgs ' -p ' qn];
end

% Walltime
wt = validatedPropValue(cluster, 'WallTime', 'char');
if ~isempty(wt)
    commonSubmitArgs = [commonSubmitArgs ' -t ' wt];
end

% Physical Memory used by a single core (K,M,G,T)
mu = validatedPropValue(cluster, 'MemUsage', 'char');
if ~isempty(mu)
    commonSubmitArgs = [commonSubmitArgs ' --mem-per-cpu=' mu];
end

% Email notification
ea = validatedPropValue(cluster, 'EmailAddress', 'char');
if ~isempty(ea)
    commonSubmitArgs = [commonSubmitArgs ' --mail-type=ALL --mail-user=' ea];
end

% Temporary Disk Space
ts = validatedPropValue(cluster, 'TempDiskSpace', 'char');
if ~isempty(ts)
    commonSubmitArgs = [commonSubmitArgs ' --tmp=' ts];
end

% Every job is going to require a certain number of MATLAB Parallel Server licenses.
% Specification of  licenses which must be allocated to this job.
%
% The /etc/slurm/slurm.conf file must list:
%
%   # MATLAB Parallel Server licenses
%   Licenses=MATLAB_Distrib_Comp_Engine:32
%
% And then call
%
%   % scontrol reconfigure
%
%commonSubmitArgs = sprintf('%s --licenses=MATLAB_Distrib_Comp_Engine:%d',commonSubmitArgs,numWorkers);

% Catch-all
asa = validatedPropValue(cluster, 'AdditionalSubmitArgs', 'char');
if ~isempty(asa)
    commonSubmitArgs = [commonSubmitArgs ' ' asa];
end

commonSubmitArgs = strtrim(commonSubmitArgs);
